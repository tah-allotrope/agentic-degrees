def fib(n):
    # Delete the pass statement below and insert your own code
    pass

class V2:
    # Delete the pass statement below and insert your own code
    pass
