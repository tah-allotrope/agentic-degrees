/*
 * Data structures used internally by the filesystem
 */

%#include <nfs3_prot.h>

struct fs_dirent {
  bool allocated;
  nfs_fh3 fh;
  filename3 filename;
};

struct fs_directory {
  fs_dirent entries<>;
};
